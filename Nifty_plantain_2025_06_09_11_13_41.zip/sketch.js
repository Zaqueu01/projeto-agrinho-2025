let playerX, playerY;
let trees = [];
let score = 0;

function setup() {
  createCanvas(600, 400);
  playerX = width / 2;
  playerY = height / 2;
  textSize(24);
}

function draw() {
  // Céu azul
  background(135, 206, 235);

  // Nuvens
  fill(255);
  noStroke();
  ellipse(100, 80, 50, 40);
  ellipse(130, 90, 50, 40);
  ellipse(70, 90, 50, 40);
  ellipse(300, 60, 50, 40);
  ellipse(330, 70, 50, 40);
  ellipse(270, 70, 50, 40);

  // Grama verde (40% parte inferior)
  fill(60, 179, 113);
  noStroke();
  rect(0, height * 0.6, width, height * 0.4);

  // Desenha árvores
  fill(34, 139, 34);
  for (let t of trees) {
    ellipse(t.x, t.y, 30, 40);
  }

  // Desenha jogador (retângulo + cabeça)
  fill(139, 69, 19);
  rect(playerX - 15, playerY - 25, 30, 50);
  fill(255, 224, 189);
  ellipse(playerX, playerY - 45, 30, 30);

  // Mostra pontuação
  fill(0);
  noStroke();
  text("Pontos: " + score, 10, 10);

  // Movimento WASD
  let speed = 4;
  if (keyIsDown(65)) playerX -= speed; // A
  if (keyIsDown(68)) playerX += speed; // D
  if (keyIsDown(87)) playerY -= speed; // W
  if (keyIsDown(83)) playerY += speed; // S

  // Limita jogador dentro da área da grama
  playerX = constrain(playerX, 15, width - 15);
  playerY = constrain(playerY, height * 0.6 + 20, height - 15);
}

function keyPressed() {
  if (key === ' ') {
    // Planta árvore na posição do jogador (um pouco abaixo da base)
    trees.push({ x: playerX, y: playerY + 10 });
    score += 10;
  }
}
